// ============================================================
// سرور UFU — بدون هیچ پکیج خارجی (فقط ماژول‌های داخلی Node.js)
// این کار عمداً انجام شده تا هنگام آپلود روی هاست (لیارا/آروان)
// هیچ مشکل نصب یا کامپایل پیش نیاد.
// ============================================================
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_PATH = path.join(__dirname, 'data', 'db.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ufu1404';
const PORT = process.env.PORT || 3000;

// ---------------- دیتابیس ساده (فایل JSON) ----------------
function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

// ---------------- نشست‌های ادمین (در حافظه) ----------------
const sessions = new Set();

function send(res, status, data, contentType) {
  contentType = contentType || 'application/json';
  const headers = { 'Content-Type': contentType, 'Access-Control-Allow-Origin': '*' };
  res.writeHead(status, headers);
  res.end(contentType === 'application/json' ? JSON.stringify(data) : data);
}

function getBody(req) {
  return new Promise(function (resolve, reject) {
    let body = '';
    req.on('data', function (chunk) { body += chunk; });
    req.on('end', function () {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function isAuthed(req) {
  const auth = req.headers['authorization'] || '';
  const token = auth.replace('Bearer ', '');
  return token && sessions.has(token);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function serveStatic(req, res, urlPath) {
  const safePath = path.normalize(urlPath).replace(/^(\.\.[\/\\])+/, '');
  let filePath = path.join(PUBLIC_DIR, safePath === '/' ? 'index.html' : safePath);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    return send(res, 403, 'دسترسی غیرمجاز', 'text/plain; charset=utf-8');
  }
  fs.readFile(filePath, function (err, content) {
    if (err) {
      return send(res, 404, 'صفحه پیدا نشد', 'text/plain; charset=utf-8');
    }
    const ext = path.extname(filePath);
    send(res, 200, content, MIME[ext] || 'application/octet-stream');
  });
}

const server = http.createServer(async function (req, res) {
  const url = new URL(req.url, 'http://' + req.headers.host);
  const pathname = url.pathname;

  // ---------- CORS preflight ----------
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    return res.end();
  }

  try {
    // ---------- اطلاعات عمومی سایت (محصولات + تنظیمات) ----------
    if (pathname === '/api/site' && req.method === 'GET') {
      const db = readDB();
      return send(res, 200, { products: db.products, config: db.config });
    }

    // ---------- ورود ادمین ----------
    if (pathname === '/api/admin/login' && req.method === 'POST') {
      const body = await getBody(req);
      if (body.password === ADMIN_PASSWORD) {
        const token = crypto.randomBytes(24).toString('hex');
        sessions.add(token);
        return send(res, 200, { token: token });
      }
      return send(res, 401, { error: 'رمز عبور اشتباه است' });
    }

    // ---------- مسیرهای محافظت‌شده ادمین ----------
    if (pathname.startsWith('/api/admin/')) {
      if (!isAuthed(req)) {
        return send(res, 401, { error: 'دسترسی غیرمجاز - دوباره وارد شوید' });
      }

      const db = readDB();

      // افزودن محصول جدید
      if (pathname === '/api/admin/products' && req.method === 'POST') {
        const body = await getBody(req);
        const product = {
          id: Date.now().toString(),
          name: body.name || '',
          price: body.price || '',
          category: body.category || '',
          badge: body.badge || '',
          image: body.image || ''
        };
        db.products.push(product);
        writeDB(db);
        return send(res, 200, product);
      }

      const itemMatch = pathname.match(/^\/api\/admin\/products\/([^\/]+)$/);

      // ویرایش محصول
      if (itemMatch && req.method === 'PUT') {
        const body = await getBody(req);
        const idx = db.products.findIndex(function (p) { return p.id === itemMatch[1]; });
        if (idx === -1) return send(res, 404, { error: 'محصول پیدا نشد' });
        db.products[idx] = Object.assign({}, db.products[idx], body, { id: itemMatch[1] });
        writeDB(db);
        return send(res, 200, db.products[idx]);
      }

      // حذف محصول
      if (itemMatch && req.method === 'DELETE') {
        db.products = db.products.filter(function (p) { return p.id !== itemMatch[1]; });
        writeDB(db);
        return send(res, 200, { ok: true });
      }

      // بروزرسانی تنظیمات سایت
      if (pathname === '/api/admin/config' && req.method === 'PUT') {
        const body = await getBody(req);
        db.config = Object.assign({}, db.config, body);
        writeDB(db);
        return send(res, 200, db.config);
      }

      return send(res, 404, { error: 'مسیر پیدا نشد' });
    }

    // ---------- فایل‌های استاتیک (index.html و admin.html) ----------
    return serveStatic(req, res, pathname);
  } catch (err) {
    console.error(err);
    return send(res, 500, { error: 'خطای سرور' });
  }
});

server.listen(PORT, function () {
  console.log('✅ سرور UFU در حال اجراست روی پورت ' + PORT);
  console.log('🌐 سایت: http://localhost:' + PORT + '/');
  console.log('🔑 پنل ادمین: http://localhost:' + PORT + '/admin.html');
  console.log('🔒 رمز پیش‌فرض ادمین: ' + ADMIN_PASSWORD + ' (حتماً با متغیر محیطی ADMIN_PASSWORD عوضش کن)');
});
